package Arrow_pannel;
import javax.swing.*;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;




public class Arrow {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			new J_Frame();
	}
}

class arrow_left extends JPanel implements KeyListener{
	private int x = 50;
	private int y = 50;
    private char keyChar = '��';

	public arrow_left(){
		addKeyListener(this);
	}
	public void keyReleased(KeyEvent ke) {
		super.setBackground(Color.black);
		repaint();
	}
	public void keyTyped(KeyEvent ke) { }
	public void keyPressed(KeyEvent ke) {
		if(ke.getKeyCode()==37){
			super.setBackground(Color.white);
			repaint();
		}
		// if ke.getkeycode() == 37 ���� 38�� 39������ 40�Ʒ�
	}
	protected void paintComponent(Graphics g){
		super.paintComponent(g);
		g.setFont(new Font("TimeRoman", Font.PLAIN, 24));
		g.drawString(String.valueOf(keyChar), x, y);
//		g.drawString(String.valueOf(keyChar), x+20, y+20);
	}
	
}

class arrow_up extends JPanel implements KeyListener{
	private int x = 50;
	private int y = 50;
	private char keyChar = '��';

	public arrow_up(){
		addKeyListener(this);
	}
	public void keyReleased(KeyEvent ke) {
		super.setBackground(Color.black);
		repaint();
	}
	public void keyTyped(KeyEvent ke) { }
	public void keyPressed(KeyEvent ke) {
		if(ke.getKeyCode()==38){
			super.setBackground(Color.white);
			repaint();
		}
		// if ke.getkeycode() == 37 ���� 38�� 39������ 40�Ʒ�
	}
	protected void paintComponent(Graphics g){
		super.paintComponent(g);
		g.setFont(new Font("TimeRoman", Font.PLAIN, 24));
		g.drawString(String.valueOf(keyChar), x, y);
//		g.drawString(String.valueOf(keyChar), x+20, y+20);
	}
	
}
class arrow_right extends JPanel implements KeyListener{
	private int x = 50;
	private int y = 50;
	private char keyChar = '��';

	public arrow_right(){
		addKeyListener(this);
	}
	public void keyReleased(KeyEvent ke) {
		super.setBackground(Color.black);
		repaint();
	}
	public void keyTyped(KeyEvent ke) { }
	public void keyPressed(KeyEvent ke) {
		if(ke.getKeyCode()==39){
			super.setBackground(Color.white);
			repaint();
		}
		// if ke.getkeycode() == 37 ���� 38�� 39������ 40�Ʒ�
	}
	protected void paintComponent(Graphics g){
		super.paintComponent(g);
		g.setFont(new Font("TimeRoman", Font.PLAIN, 24));
		g.drawString(String.valueOf(keyChar), x, y);
//		g.drawString(String.valueOf(keyChar), x+20, y+20);
	}
	
}
class arrow_down extends JPanel implements KeyListener{
	private int x = 50;
	private int y = 50;
	private char keyChar = '��';

	public arrow_down(){
		addKeyListener(this);
	}
	public void keyReleased(KeyEvent ke) {
		super.setBackground(Color.black);
		repaint();
	}
	public void keyTyped(KeyEvent ke) { }
	public void keyPressed(KeyEvent ke) {
		if(ke.getKeyCode()==40){
			super.setBackground(Color.white);
			repaint();
		}
		// if ke.getkeycode() == 37 ���� 38�� 39������ 40�Ʒ�
	}
	protected void paintComponent(Graphics g){
		super.paintComponent(g);
		g.setFont(new Font("TimeRoman", Font.PLAIN, 24));
		g.drawString(String.valueOf(keyChar), x, y);
//		g.drawString(String.valueOf(keyChar), x+20, y+20);
	}
	
}


class J_Frame extends JFrame{
	public J_Frame(){
		Container ct = getContentPane();
		
		ct.setLayout(new GridLayout(3, 3, 5, 5));
		JPanel[] jp = new JPanel[9];
		for(int i=0; i<jp.length ; i++){
			jp[i] = new JPanel();
			ct.add(jp[i]);
		}
		jp[1] = new arrow_up();
		jp[3] = new arrow_left();
		jp[5] = new arrow_right();
		jp[7] = new arrow_down();
		jp[1].setFocusable(true);
		jp[3].setFocusable(true);
		jp[5].setFocusable(true);
		jp[7].setFocusable(true);
		
		setTitle("ȭ��ǥ�� �׸���**");
		setSize(600,600);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}
}