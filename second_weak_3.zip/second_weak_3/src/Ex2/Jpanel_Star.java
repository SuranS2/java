package Ex2;

import javax.swing.*;
import java.awt.*;
import java.util.Scanner;
public class Jpanel_Star {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			new J_PanelStar();
	}

}

class J_PanelStar extends JFrame{
	public J_PanelStar(){
		int key = key();
		Container ct = getContentPane();
		
		ct.setLayout(new GridLayout(key, (key*2-1), 5 , 5 ));
		JPanel[] jp = new JPanel[key*(key*2-1)];
		//3�� ������ 0~8
		int j =0;
		int limit = key;
		for(int i = 0; i < key ; i++){
			System.out.println(i + " int i ");
			//012
			for(int k=0 ; k<i;k++){
				//i�� 0 ���� x
				System.out.println(j + " white");
				jp[j]= new JPanel();
				ct.add(jp[j]);
				jp[j].setBackground(Color.WHITE);
				j++;
			}
			for(int k=0 ; k< (limit*2-1); k++){
				//i=0; ���� 5��
				System.out.println(j +"black");
				jp[j]= new JPanel();
				ct.add(jp[j]);
				jp[j].setBackground(Color.BLACK);
				j++;
			}
			//j 01234
			for(int k=0 ; k<i; k++){
				System.out.println(j);
				jp[j]= new JPanel();
				ct.add(jp[j]);
				jp[j].setBackground(Color.WHITE);
				j++;
			}
			limit--;
		}
		setTitle("����� ���� **");
		setSize(300,400);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}
	private int key(){
		Scanner sc = new Scanner(System.in);
		System.out.println("�ܼ��� �Է��Ͻÿ�");
		int num = sc.nextInt();
		return num;
	}
}