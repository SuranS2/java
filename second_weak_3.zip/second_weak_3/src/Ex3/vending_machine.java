package Ex3;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class vending_machine {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			new J_Panel();
	}

}

class J_Panel extends JFrame implements ActionListener{
	private JTextField jtf;
	private JTextArea jta;
	public J_Panel(){
		jtf = new JTextField(30);
		jta = new JTextArea(1,30);
		jtf.addActionListener(this);
		Container ct = getContentPane();
		ct.setLayout(new BorderLayout());
		JPanel[] jp = new JPanel[3];
		String[] b_str = {"�ݶ�(1000)", "���̴�(800)", "ȯŸ(700)", ""};
		for(int i = 0; i < 3 ; i++){
			jp[i]= new JPanel();
			if(i==0){
				jp[i].add(jtf);
				ct.add(jp[i], BorderLayout.NORTH);
			}else if(i==1){
				jp[i].setLayout(new GridLayout(2,2,0,0));
				ct.add(jp[i], BorderLayout.CENTER);
				for(int j = 0 ; j < 4 ; j++){
					jp[i].add(new JButton(b_str[j]));
				}
			}else if(i==2){
				jp[i].add(jta);
				ct.add(jp[i], BorderLayout.SOUTH);
			}
		}
		setTitle("���Ǳ� UI �����");
		setSize(300,200);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}
	public void actionPerformed(ActionEvent ae) {
		jta.append(ae.getActionCommand());
		jtf.setText("");
	}
}
