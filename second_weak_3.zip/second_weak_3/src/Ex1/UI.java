package Ex1;
import javax.swing.*;
import java.awt.*;

public class UI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			new J_Panel();
	}

}

class J_Panel extends JFrame{
	public J_Panel(){
		Container ct = getContentPane();
		ct.setLayout(new GridLayout(3, 1));
		JPanel[] jp = new JPanel[3];

		for(int i = 0; i < 3 ; i++){
			jp[i]= new JPanel();
			if(i==0){
				jp[i].setLayout(new FlowLayout( FlowLayout.CENTER ,50, 15));
				ct.add(jp[i]);
			}else if(i==1){
				jp[i].setLayout(new GridLayout(1,3,0,0));
				ct.add(jp[i]);
			}else if(i==2){
				jp[i].setLayout(new BorderLayout());
				ct.add(jp[i]);
			}
			for(int j = 1+(i)*3 ; j <= (i+1)*3 ; j++){
				if(j==7){
					jp[i].add(new JButton(Integer.toString(j)), BorderLayout.WEST);
					continue;
				}else if(j==8){
					jp[i].add(new JButton(Integer.toString(j)), BorderLayout.CENTER);
					continue;
				}else if(j==9){
					jp[i].add(new JButton(Integer.toString(j)), BorderLayout.EAST);
					continue;
				}
				jp[i].add(new JButton(Integer.toString(j)));
			}
		}
		setTitle("�ڹ� �ǽ�");
		setSize(300,300);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}
}